package banking.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import banking.bean.BankAccount;
import banking.bean.Transaction;

public interface BankAccountDao {
	public void CreateAccount(String accountName, long phoneNo, long accountBalance) throws ClassNotFoundException, SQLException;
	
	public BankAccount displayBalance(int accountNo)throws ClassNotFoundException, SQLException;

	public BankAccount deposit(int accountNo, double amount)throws ClassNotFoundException, SQLException;

	public BankAccount withdraw(int accountNo, double amount)throws ClassNotFoundException, SQLException;

	public List<BankAccount> fundTransfer(int accountNo1, int accountNo2, double amount)throws ClassNotFoundException, SQLException;

	/*public Transaction printTransactions(int accountNo);

	public void update(int accountNo, BankAccount bankAccount);*/
}
