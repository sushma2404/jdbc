package banking.exception;

public class InsufficientBalanceException extends Exception {
	public InsufficientBalanceException(String s) {
		super(s);
	}

}
