package banking.service;

import java.sql.SQLException;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import banking.bean.BankAccount;
import banking.bean.Transaction;
import banking.exception.InsufficientBalanceException;
import banking.exception.InvalidAccountException;

public interface BankAccountService {
	public void CreateAccount(String accountName, long phoneNo, long accountBalance) throws ClassNotFoundException, SQLException;

	public double displayBalance(int accountNo)throws ClassNotFoundException, SQLException;

	public void deposit(int accountNo, double amount)throws ClassNotFoundException, SQLException;

	public void withdraw(int accountNo, double amount)throws ClassNotFoundException, SQLException;

	public void fundTransfer(int accountNo1, int accountNo2, double amount)throws ClassNotFoundException, SQLException;

	/*public void printTransactions(int accountNo);*/
}
